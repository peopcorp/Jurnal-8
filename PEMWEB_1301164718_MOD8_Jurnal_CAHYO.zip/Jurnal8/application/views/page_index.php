  <div class="container" style="margin-top: 50px">
    <br><br><br>
    <h1 class="text-center">Sistem Informasi Telkom University</h1>
    <img class="center-block" src="<?php echo base_url('assets/img/logo.png') ?>" width="450px">
  </div>
</body>
</html>
