<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function __construct()
 	{
 		// Load M_Web as parents in here.
 		parent::__construct();
		//load model "Mahasiswa_model"
		$this->load->model('M_web');		
  	}

  	public $data = array(
  		"nim" => "1301164718",
  		"nama" => "RYAN RAMDHANI",
  		"kampus"=>"Telkom University"
  	);

	public function index()
	{
		//Load page_header and page_index from views
		$this->load->view('page_header');
		$this->load->view('page_index');
	}

	public function mahasiswa()
	{
		$data_mahasiswa = $this->M_web->Getmahasiswa_nim();
		$data_jurusan = $this->M_web->Getjurusan_nim();
		$this->load->view('page_header',['dataJ'=>$data_jurusan]);
		$this->load->view('page_mahasiswa',['data'=>$data_mahasiswa]);
	}

	public function jurusan()
	{
		$data_jurusan = $this->M_web->Getjurusan_nim();
		$this->load->view('page_header');
		$this->load->view('page_jurusan',['data'=>$data_jurusan]);
	}


	#lengkapi FUNCTION BERIKUT
	public function hapusmahasiswa($nim)
	{

		//Load function hapus_mahasiswa from M_web
		// make it to index.php/web/mahasiswa after delete complete
		if (!isset($nim)){
        	show_404();
        }
        if ($this->M_web->hapus_mahasiswa($nim)) {
        $this->session->set_flashdata('flash', 'dihapus');	

        redirect(site_url('page_index'));	        	
        }

	}


	public function tambahmahasiswa()
	{
		
		// Create variabel and use it for input data to database.
		// Load tambah_mahasiswa($data) from M_web
		// Redirect to index.php/web/mahasiswa after add data.
		$data = array(
			'nim' => $this->input->post('nim'),
			'nama' => $this->input->post('nama'),
			'kelas' => $this->input->post('kelas'),
			'id_jurusan' => $this->input->post('jurusan'),
		);

		$cek = $this->M_web->tambah_mahasiswa($data);
		if ($cek) $this->session->set_flashdata('info', 'Mahasiswa berhasil ditambah');
		else $this->session->set_flashdata('info', 'Mahasiwa gagal ditambah');
		redirect('index.php/web/mahasiswa');
 
	}

	public function editmahasiswa($nim)
	{

		// Create variabel and use it for edit data from database.
		// Load edit_mahasiswa($nim,$data) from M_web
		// Redirect to index.php/web/mahasiswa after edit data.
		$data =
			array(
				'nama' => $this->input->post('nama'),
				'kelas' => $this->input->post('kelas'),
				'id_jurusan' => $this->input->post('jurusan'),
			);
		$this->M_web->edit_mahasiswa($nim, $data);
		redirect('index.php/web/mahasiswa');
		


	}


	#lengkapi FUNCTION BERIKUT UNTUK PAGE JURUSAN



	public function tambahjurusan()
	{

		// Create variabel and use it for add data from database.
		// Load tambah_jurusan($data) from M_web
		// Redirect to index.php/web/jurusan after add data.
		$data = array (
			'id_jurusan' => $this->input->post('id_jurusan'),
			'nama_jurusan' => $this->input->post('nama_jurusan'),
			'fakultas' => $this->input->post('fakultas'),
			'akreditasi' => $this->input->post('akreditasi'),
		);

		$cek = $this->M_web->tambah_jurusan($data);
		if ($cek) $this->session->set_flashdata('info', 'Jurusan berhasil ditambah');
		else $this->session->set_flashdata('info', 'Jurusan gagal ditambah');
		redirect('index.php/web/jurusan');


	

	}

	public function editjurusan()
	{

		// Create variabel and use it for add data from database.
		// Load edit_jurusan($id_jurusan,$data) from M_web
		// Redirect to index.php/web/jurusan after add data.
		$data = [
			'id_jurusan' => $this->input->post('id_jurusan'),
			'nama_jurusan' => $this->input->post('nama_jurusan'),
			'fakultas' => $this->input->post('fakultas'),
			'akreditasi' => $this->input->post('akreditasi'),
		];

		$cek = $this->M_web->edit_jurusan($id_jurusan, $data);
		if ($cek) $this->session->set_flashdata('info', 'Data Jurusan berhasil diubah');
		else $this->session->set_flashdata('info', 'Data Jurusan gagal diubah');
		redirect('index.php/web/mahasiswa');


	
	}

	public function hapusjurusan($id_jurusan)
	{

		// Create variabel and use it for add data from database.
		// Load hapus_jurusan($id_jurusan) from M_web
		// Redirect to index.php/web/jurusan after add data.
		if (!isset($id_jurusan)){
        	show_404();
        }
        if ($this->M_web->hapus_jurusan($id_jurusan)) {
        $this->session->set_flashdata('flash', 'Dihapus . .');	

        redirect(site_url('index.php/web/jurusan'));	        	
        }

	}
}
