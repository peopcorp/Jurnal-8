<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_web extends CI_Model {

	//COMPLETE ALL FUNCTION IN HERE
	
	public function GetMahasiswa_nim(){
		$this->db->select('*');
		$this->db->from('mahasiswa');
		$this->db->join('jurusan','jurusan.id_jurusan=mahasiswa.id_jurusan','LEFT OUTER');
		$query = $this->db->get();
		return $query->result();
	}
	public function Getjurusan_nim(){
		$this->db->select('*');
		$this->db->from('jurusan');
		$query = $this->db->get();
		return $query->result();
	}


	//COMPLETE ALL FUNCTION IN HERE

	//FUNCTION TO DELETE MAHASISWA
	public function hapus_mahasiswa($nim)
	{
		return $this->db->delete('mahasiswa', array("nim" => $nim));
	}

	//FUNCTION TO DELETE EDIT
	public function edit_mahasiswa($nim,$data)
	{
		
		$this->db->where('nim',$nim);
		return $this->db->update('mahasiswa',$data);
	}

	//FUNCTION TO ADD MAHASISWA
	public function tambah_mahasiswa($data)
	{
	
		$this->db->insert('mahasiswa', $data);
		return;
	}


	//FUNCTION TO DELETE MAJORS

	public function hapus_jurusan($id_jurusan)
	{
		return $this->db->delete('jurusan', array("id_jurusan" => $id_jurusan));
	}


	//FUNCTION TO EDIT MAJORS
	public function edit_jurusan($id_jurusan,$data)
	{
		$data = [
			"id_jurusan" => $this->input->post('id_jurusan', true),
		];
		$this->db->where('id_jurusan',$id_jurusan);
		return $this->db->update('jurusan',$data);
		return $this->db->result_array();
	}


	//FUNCTION TO ADD MAJORS
	public function tambah_jurusan($data)
	{
		$data = [
			"jurusan" => $this->input->post('jurusan', true),
		];
		$this->db->where('jurusan',$jurusan);
		return $this->db->update('jurusan',$data);
		return $this->db->result_array();
	}



}
